import json
import sys

with open('../ipPoolsConfig.json', 'r') as json_file:
    data = json.load(json_file)
    json.dump(data, sys.stdout)
