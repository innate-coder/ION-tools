$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig = new Object();

var dbManagementIp = $.stack_params.cbam.externalConnectionPoints.dbManagementECP.addresses["0"].ip;
var dbExternalIp = $.stack_params.cbam.externalConnectionPoints.dbExtECP.addresses["0"].ip;
var dbManagementGatewayIp = $.stack_params.cbam.extensions.dbManagementGatewayIp;
var dbManagementNetmask = $.stack_params.cbam.extensions.dbManagementNetmask;
var numberOfCtrlWorkers = $.stack_params.cbam.extensions.numberOfCtrlWorkers;
var numberOfUserWorkers = $.stack_params.cbam.extensions.numberOfUserWorkers;
var dbUsername = $.stack_params.cbam.extensions.dbUsername;
var numberOfRedisInstances = $.stack_params.cbam.extensions.numberOfRedisInstances;
var dbExternalNetmask = $.stack_params.cbam.extensions.dbExternalNetmask;
var primaryDnsServerIp = $.stack_params.cbam.extensions.primaryDnsServerIp;
var secondaryDnsServerIp = $.stack_params.cbam.extensions.secondaryDnsServerIp;
var publicSshKey = $.stack_params.cbam.publicSshKey;

var convertedManagementNetMask = transcodeNetMask(dbManagementNetmask);
var convertedExternalNetMask = transcodeNetMask(dbExternalNetmask);

var redisBlock = generateRedisInstanceBlock(dbExternalIp,numberOfRedisInstances);

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.eth0 = "DEVICE=eth0\nBOOTPROTO=none\nONBOOT=yes\nNETMASK=" + convertedManagementNetMask + "\nIPADDR=" + dbManagementIp + "\nUSERCTL=yes\nGATEWAY=" + dbManagementGatewayIp + "\nDNS1=" + primaryDnsServerIp + "\nDNS2=" + secondaryDnsServerIp + "\n";

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.eth1 = "DEVICE=eth1\nBOOTPROTO=none\nONBOOT=yes\nNETMASK=" + convertedExternalNetMask + "\nIPADDR=" + dbExternalIp + "\nUSERCTL=yes\n";

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.db = "NUM_INSTANCES=" + numberOfRedisInstances + "\n";

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.db_proxy = "{\n    \"libcool\": {\n        \"daemon\": 0,\n        \"logging\": {\n            \"verbose\": 2,\n            \"syslog\": \"DB_PROXY\",\n            \"color\": 0,\n            \"ctxsys\": 1,\n            \"ctxusr\": 1\n        },\n        \"core\": {\n            \"bufamnt\": 1000000\n        }\n    },\n    \"db_proxy\": {\n        \"listen_servers\": [\n            {\n                \"addr\": \"0.0.0.0\",\n                \"port\": 5678,\n                \"amount\": 100\n            }\n        ],\n        \"redis_servers\": [\n            " + redisBlock + "\n        ],\n        \"user_workers\": " + numberOfUserWorkers + ",\n        \"ctrl_workers\": " + numberOfCtrlWorkers + ",\n        \"keep_alive_time\": 60,\n        \"keep_alive_intvl\": 30,\n        \"keep_alive_probes\": 5\n    }\n}\n";

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.card_conf = "card=cdb\n";

$.stack_params.cbam.resources.dbAspectGroup["0"].dbInstanceGroup["0"].dbServerInstance.dbConfig.userKey = publicSshKey + " " + dbUsername + "@localhost";

return $.stack_params

function transcodeNetMask(originalPrefix) {
  var mask=[];
  for(i=0;i<4;i++) {
    var n = Math.min(originalPrefix, 8);
    mask.push(256 - Math.pow(2, 8-n));
    originalPrefix -= n;
  }
  return mask.join('.');
}

function generateRedisInstanceBlock(dbExternalIp,numberOfRedisInstances) {
   var tempRedis = [];
   var additionalContent = ",\n            ";
   var redisPort = 6379;

   for (i=0; i<numberOfRedisInstances; i++) {

       var block = "{\n                \"addr\": \"" + dbExternalIp + "\",\n                \"port\": " + redisPort + "\n            }";
       tempRedis.push(block);

       if (i < numberOfRedisInstances-1) {
           tempRedis.push(additionalContent);
       }

       redisPort++;
   }

   return tempRedis.join("");

}
